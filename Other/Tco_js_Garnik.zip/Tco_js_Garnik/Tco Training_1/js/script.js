let a = [1,2,3,4,5,6,7,8,9]

a.forEach(function(x){
    if(x%2==0)
    alert(x)
    console.log(x);

})

