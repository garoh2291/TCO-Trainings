/* --  array1 =>    -- */

// let myArr = [1 ,4 , 9 , 3 , 8 , 9 , 5 , 5 ,11 , 1 , 18]
// myArr.sort()
// newArr = []
// console.log(myArr);



// function sameNumb(){
//     for(let i = 0 ; i < myArr.length ; i++){
//         if(myArr[i] == myArr[i+1]){
//             newArr.push(myArr[i])
            
    
//         }
//     }

//     console.log(newArr.length);
// }


// sameNumb()


// let lang = {
//     arm: {
//         translate: 'Բարև'
//     },
//     rus: {
//         translate: 'Privet'
//     },
//     eng : {
//         translate: 'Hello'
//     }

// }


// function langFunc(x){
//     document.write(lang[x].translate) 

// }






