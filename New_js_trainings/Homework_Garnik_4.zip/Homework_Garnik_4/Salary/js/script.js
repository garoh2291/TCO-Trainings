let bigFirm = [
    {Position: 'CEO' , Name : 'Alex' , Salary: '1200$'},
    {Position: 'CTO' , Name : 'Sam' , Salary: '1150$'},
    {Position: 'SEO' , Name : 'Viktoria' , Salary: '1040$'},
    {Position: 'Project Manager' , Name : 'Arthur' , Salary: '980$'},
    {Position: 'Product Manager' , Name : 'Anna' , Salary: '870$'},
    {Position: 'Front-End Developer' , Name : 'Erik' , Salary: '610$'},

]


let salaryCount = (bigFirm.map(x => parseFloat(x.Salary)))


// console.log(salaryCount);

let salaryPerMonth = salaryCount.reduce((a,b) => a + b)


console.log(`this company spends $ ${salaryPerMonth} on salary every month`);