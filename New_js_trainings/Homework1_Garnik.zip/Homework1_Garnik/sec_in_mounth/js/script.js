
let minute = 60 ;

let hour = 60 * minute;
let day = 24 * hour;
let mounth = 30 * day;


console.log(`There are ${hour} per 1 Hour!!!`);
console.log(`There are ${day} per 1 Day!!!`);
console.log(`There are ${mounth} per 1 Month!!!`);