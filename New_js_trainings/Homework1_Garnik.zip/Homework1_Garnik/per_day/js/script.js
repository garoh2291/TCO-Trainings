
let minute =  60 ;
let hour = 60 ;
let day = 24 ;


let minutePerDay = day * hour;
let secPerDay = day * hour * minute ;

console.log(`There are ${secPerDay} seconds , ${minutePerDay} miuntes and ${day} hours in one day!!!`);

