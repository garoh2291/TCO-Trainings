let randNumb =  Math.random()
let bigRand = Math.round(randNumb * 100) + 100

while(bigRand > 50){
    bigRand-=5;
    console.log(bigRand);
}

if(bigRand <=50){
    alert('Stop')
}

