let salary = prompt("How much money you earn per week by USD??");
salary = parseFloat(salary);
let a = salary * 481 ;

console.log(`You earn per week ${a} AMD!`)
