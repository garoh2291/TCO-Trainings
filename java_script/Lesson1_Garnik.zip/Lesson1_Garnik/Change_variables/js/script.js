let firstVar = 15 ;
let secondVar = 22 ;

firstVar = firstVar + secondVar ;
secondVar = firstVar - secondVar ;
firstVar = firstVar - secondVar ;


console.log(firstVar) ;
console.log(secondVar) ;