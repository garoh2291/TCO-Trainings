let fName = "Garnik" ;
let age = 29 ;
let webDev = confirm("Are You going to web development classes?") ;
let petName = prompt("What is pet name?") ;


console.log(`My name is ${fName}`); 
console.log(`I am ${age} years old.`);
console.log(`It's ${webDev} that I am going to web development classes.`);
console.log(`Your pet name is ${petName}.`);

