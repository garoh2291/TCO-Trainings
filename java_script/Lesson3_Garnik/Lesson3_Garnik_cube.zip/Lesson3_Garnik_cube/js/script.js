let cubSize = document.getElementById("myCube");
let n = 200
let i=0


function bigCube(){
  
    if(n <= n + 1){
        n += 5 
        i += 30
    }
    cubSize.style.width = `${n}px`
    cubSize.style.height = `${n}px`
    cubSize.style.transform = `rotate(${i}deg)`

}





